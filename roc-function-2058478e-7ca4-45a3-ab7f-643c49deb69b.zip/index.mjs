import { DynamoDB, DynamoDBClient, ListTablesCommand, PutItemCommand, UpdateItemCommand, GetItemCommand,DeleteItemCommand, CreateTableCommand } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand, PutCommand,GetCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";
import { S3, S3Client, CreateBucketCommand, DeleteBucketCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { APIGateway, APIGatewayClient, CreateApiKeyCommand } from "@aws-sdk/client-api-gateway";

const REGION = "us-east-2";

//DynamoDB Document Client
const marshallOptions = {
    //Whether to automatically convert empty strings, blobs, and sets to 'null'
    convertEmptyValues: false,
    //Whether to remove undefined values while marshalling
    removeUndefinedValues: false,
    //Whether to convert typeof object to map attribute
    convertClassInstanceToMap: false,
};

const unmarshallOptions = {
    //Whether to return numbers as a string instead of converting them to native JS numbers
    wrapNumbers: false,
};

const translateConfig = {marshallOptions, unmarshallOptions};

//DynamoDB Service Client
export const client = new DynamoDBClient({});

export const doc = DynamoDBDocumentClient.from(client, translateConfig);

//S3 Service Client
export const s3 = new S3Client({ region: REGION });

//API Gateway Service Client
export const apiGate = new APIGatewayClient({ region: REGION });


export const userData = await doc.send(new GetCommand({
    TableName: 'roc-proj-table',
    Key: {
        'id': '0',
    },
}));


export const EXISTING_TABLES = await client.send(new ListTablesCommand({}));
export const TABLE_NAME = (userData.Item.fname + userData.Item.lname).toLowerCase();
export const projs = Array.from(userData.Item.projects).join(', ');
export const tables = Array.from(EXISTING_TABLES.TableNames);

if(tables.includes(TABLE_NAME) == false) {
    const createTableParams = {
        KeySchema: [
            {
                AttributeName: "date",
                KeyType: "HASH",
            },
            {
                AttributeName: "project",
                KeyType: "RANGE",
            }
        ],
        AttributeDefinitions: [
            {
                AttributeName: "date",
                AttributeType: "S",
            },
            {
                AttributeName: "project",
                AttributeType: "S",
            }
        ],
        ProvisionedThroughput: {
            ReadCapacityUnits: 1,
            WriteCapacityUnits: 1,
        },
        TableName: TABLE_NAME,
        StreamSpecification: {
            StreamEnabled: false,
        }
    };
    
    await client.send(new CreateTableCommand(createTableParams));
}

/*
export const reportData = await doc.send(new GetCommand({
    TableName: TABLE_NAME,
    Key: {
        'date': '0',
    },
}));
*/

export const streamToString = (stream) => new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (chunk) => chunks.push(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
});

export const getFileFromS3 = async () => {
    const s3param = {
        Bucket: 'roc-api-bucket',
        Key: 'sample.json'
    };
    
    const command = new GetObjectCommand(s3param);
    const response = await s3.send(command);
    
    const { Body } = response;
    
    return streamToString(Body);
};

const file = JSON.parse(await getFileFromS3());

export const handler = async(event, context, callback) => {
    var response;
    
    try {
        /*
        if(Array.from(userData.Item.projects).length == 1) {
            response = {
                statusCode: 200,
                body: JSON.stringify("Hello, " + userData.Item.fname + ". Welcome to ROC! Hope your " + projs + " project is going well. What reports do you have today?")
            };
        }
        else {
            response = {
                statusCode: 200,
                body: JSON.stringify("Hello, " + userData.Item.fname + ". Welcome to ROC! Hope you " + projs + " projects are going well. What reports do you have today?")
            };
        }
        */
        
        
        
        if(file.routeKey == 'PUT') {
            var newDataParams = {
                Item: {
                    "date": file.date,
                    "project": file.project,
                    "report": file.report,
                    "reportStatus": file.reportStatus
                },
                TableName: TABLE_NAME
            };
            
            await client.send(new PutCommand(newDataParams));
            
            response = {
            statusCode: 200,
            body: JSON.stringify("SUBMITTED")
            };
        }
        else if(file.routeKey == 'DELETE') {
            await doc.send(new DeleteCommand({
                TableName: TABLE_NAME,
                Key: {
                    "date": file.date,
                    "project": file.project
                }
            }));
            
            response = {
            statusCode: 200,
            body: JSON.stringify("DELETED")
            };
        }
        else if(file.routeKey == 'GET') {
            const reportData = await doc.send(new GetCommand({
                TableName: TABLE_NAME,
                Key: {
                'id': '03/02/23',
                },
            }));
            
            response = {
            statusCode: 200,
            body: JSON.stringify(reportData.Item.id + " " + reportData.Item.report + " " + reportData.Item.reportStatus)
            };
        }
        
        callback(null, response);
    } catch(err) {
        console.log("Error", err);
    }
};