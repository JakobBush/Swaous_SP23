export class Constants {
  public static ADMIN_ROUTES = {
    JOBS: '/jobs',
  };

  public static APIS = {
    JOBS: '/board/jobs',
  };
}
