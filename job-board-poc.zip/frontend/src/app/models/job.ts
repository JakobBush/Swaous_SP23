export interface Job {
    id: string;
    title: string;
    description: string;
    companyName: string;
    location: string;
    level: string;
}
