//TODO: Replace the xxxxx in the below url with the url created in API Gateway after deploying the backend via serverless.

export const environment = {
  state: 'production',
  production: true,
  apiUrl: 'https://xxxxx.execute-api.us-east-1.amazonaws.com',
}
